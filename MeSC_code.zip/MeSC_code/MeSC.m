function result=MeSC(X,y,lambda1,lambda2,k,max_iter)
% Preserving Local and Global Information: An Effective Metric-based 
% Subspace Clustering(MeSC)----Apr., 2023.
% max_iter : Maximum Number of Iterations
% lambda1,2 : Trade-off parameter for penalty term ||S||_F^2
% k            : Order of the low-pass filter based on normalized Laplacian Fourier base
% X            : n*m data matrix, each column(feature) represents a graph signal
% y            : num*1 cluster indicator vector
    if nargin <6
        max_iter=50;
    end
    
    [n,~] = size(X);  
    nCluster = length(unique(y));  
    X = double(X);
    tic;
    X = X./repmat(sqrt(sum(X.^2)), [size(X,1) 1]);

    % ==== init C0 ====
    C = (X*X' + lambda1*eye(n))\(X*X');
    C = max(C,0);
    C = (C + C')/2;
    C = C - diag(diag(C));

    %===== iter =====
    S = zeros(n,n);
    iter = 0;
    bStop = 0 ;
    % for iter = 1:max_iter
    while ~bStop  
        iter = iter + 1;
        D = 1-corr(C,'type','Pearson');
        %=== update S ===
        Dit = -(D.*D)/(2*lambda2);
        for ic = 1:n
            S(ic,:) = EProjSimplex_new(Dit(ic,:)); 
        end
        %======= update filter ====
        S = (S + S')/2;
        X_bar = X;
        if k > 0
            Ds = diag(sum(S));
            Ls = Ds - S;
            % === k order ===
            for i = 1:k 
                X_bar = (eye(n) - Ls/2)*X_bar;
            end
        end
        %==== update C ====
        C = (X_bar*X_bar' + lambda1*eye(n))\(X_bar*X_bar');
        C = max(C,0);
        C = (C + C')/2;
        C = C - diag(diag(C));
        %==== LOSS ====
        temp = (D.*D).*S;
        Loss(iter) = norm(X_bar'-(X_bar'*C),'fro')^2 + lambda1*norm(C,'fro')^2 + lambda2*norm(S,'fro')^2 + sum(temp(:));
        if (iter > 1) && ((iter > max_iter)||(abs(Loss(iter-1)-Loss(iter))/Loss(iter-1) <= 1e-6))
            bStop = 1;
        end
    end
    W = (abs(S) + abs((S)'))/2;
    [C] = SpectralClustering(W, nCluster);
    Tim=toc;
    result = EvaluationMetrics(y, C);
end

